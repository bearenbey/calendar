# calendar_app/__init__.py

# You can optionally expose your entry function here:
from .app import run
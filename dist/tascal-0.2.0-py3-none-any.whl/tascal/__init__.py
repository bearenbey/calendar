# tascal/__init__.py

# Optional: expose the run function at the package level
from .cli import run

__all__ = ['run']